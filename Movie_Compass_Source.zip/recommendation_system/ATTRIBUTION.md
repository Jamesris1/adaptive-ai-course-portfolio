# Attribution and resource credits

## Foundation

shyam1998. (2020). *Movie Recommendation System GUI* [Source code]. GitHub. https://github.com/shyam1998/Movie-Recommendation-System-GUI

Reviewed commit: `ef2a6020da3ba9f9af1f2da2341edc386d1adb86`. The retained `upstream/imdb_recommendation_system.py` is an unmodified comparison copy. Its MIT notice is in `upstream/LICENSE`. The new implementation adapts the idea and structure of encoding genres and ranking cosine similarity; interface, feature weighting, multi-favorite profile, validation, filtering, reranking, tests, and evaluation were rewritten for this project. The upstream IMDb data, images, music, and Tkinter code are not redistributed.

## Data

Harper, F. M., & Konstan, J. A. (2015). The MovieLens datasets: History and context. *ACM Transactions on Interactive Intelligent Systems, 5*(4), Article 19. https://doi.org/10.1145/2827872

GroupLens. (2018). *MovieLens latest small dataset*. https://grouplens.org/datasets/movielens/latest/

Dataset usage conditions and citation instructions are preserved verbatim in `data/README.txt`. The software's license does not replace the data license. No endorsement by GroupLens or the University of Minnesota is implied.

## Design and technical learning

Albini, G. (2023, April 12). *Building a movie recommender web app from scratch with SVD and Flask: Part 1*. https://gabri-albini.medium.com/building-a-movie-recommender-web-app-from-scratch-with-svd-and-flask-part-1-ff4d39b837ea

Albini, G. (2023, April 12). *Building a movie recommender web app from scratch with SVD and Flask: Part 2*. https://gabri-albini.medium.com/building-a-movie-recommender-web-app-from-scratch-with-svd-and-flask-part-2-ba8a7b34b020

Scikit-learn developers. *Feature extraction*. https://scikit-learn.org/stable/modules/feature_extraction.html

Surprise developers. *Matrix factorization-based algorithms*. https://surprise.readthedocs.io/en/stable/matrix_factorization.html

Flask is used for the local web service; NumPy, SciPy, and scikit-learn support numerical/vector operations; pytest is used for testing. Versions and transitive dependencies are pinned in `requirements.txt`. No SVD or Apriori implementation is claimed in this content-based system. Those methods are compared in the report.

AI assistance was used to develop, debug, test, and document this submission. The owner should review and understand the implementation and follow the course's disclosure policy. No participant testing or personal learning history was invented.
