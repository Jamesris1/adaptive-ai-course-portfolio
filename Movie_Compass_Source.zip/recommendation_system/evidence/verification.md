# Verification record

Date: October 4, 2026. Platform: Windows, Python 3.12.14.

- Automated tests: 22 passed. Covers real catalog/search, exact cosine calculation, explanation consistency, deterministic ranking, no duplicate/seed/hidden results, year and genre filters, empty-result recovery, missing metadata, malformed inputs, privacy headers, and variety control.
- Browser: the example produced eight cards from 5,070 eligible films; hiding Antz removed it and reduced the pool to 5,069; undo restored it and the original pool.
- Browser: an earliest year of 9999 produced the actionable no-matches message without a crash.
- Layout: desktop browser screenshot inspected; readable labels, controls, cards, and visible explanations.
- Offline experiment: run `evaluate.py`; complete methodology and raw aggregate results are saved in `evaluation.json`.

These are developer checks, not a usability study. No task completion rate, SUS score, participant satisfaction, or fairness result is claimed.

Implementation challenges and responses: Python's bundled TLS trust configuration initially rejected the dataset download; downloading through PowerShell with certificate validation succeeded. Feature ties remain when movies share the same genres; deterministic ordering makes them reproducible but does not resolve missing information. A global time split left only 28 eligible users, so results are described as exploratory. The genre model underperformed popularity; its measured limitations are retained rather than hidden by retuning against the test set. Git command-line authentication was unavailable; the authenticated GitHub web session provided the publication route.
