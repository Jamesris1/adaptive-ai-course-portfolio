"""Content-based extension of shyam1998's genre/cosine movie recommender.

See ATTRIBUTION.md and upstream/LICENSE. Scores are similarity, not ratings.
"""
from pathlib import Path
import csv
import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize

ROOT = Path(__file__).resolve().parent


def genre_tokens(text):
    return [] if text == '(no genres listed)' else text.split('|')


class MovieRecommender:
    def __init__(self, path=ROOT / 'data' / 'movies.csv'):
        with Path(path).open(encoding='utf-8', newline='') as file:
            rows = list(csv.DictReader(file))
        self.movies = []
        for row in rows:
            year = re.search(r'\((\d{4})\)\s*$', row['title'])
            self.movies.append({'id': int(row['movieId']), 'title': row['title'],
                                'genres': genre_tokens(row['genres']),
                                'year': int(year[1]) if year else None})
        self.index = {m['id']: i for i, m in enumerate(self.movies)}
        if len(self.index) != len(self.movies):
            raise ValueError('Movie IDs must be unique.')
        self.vectorizer = TfidfVectorizer(analyzer=genre_tokens, norm='l2', dtype=np.float64)
        self.features = self.vectorizer.fit_transform([r['genres'] for r in rows])
        self.genres = sorted(self.vectorizer.get_feature_names_out().tolist())

    def search(self, query, limit=20):
        query = query.strip().casefold()
        if len(query) < 2:
            return []
        return [m for m in self.movies if query in m['title'].casefold()][:limit]

    def recommend(self, seeds, *, hidden=(), genre='', avoid_horror=False,
                  min_year=0, max_year=9999, diversity=0.15, limit=8):
        seeds = list(dict.fromkeys(seeds))
        if not 1 <= len(seeds) <= 5:
            raise ValueError('Choose one to five favorite movies.')
        if any(type(x) is not int or x not in self.index for x in seeds):
            raise ValueError('Choose favorites from the search results.')
        if not 0 <= diversity <= 0.5 or not 1 <= limit <= 20:
            raise ValueError('Choose a supported variety level and result count.')
        if min_year > max_year:
            raise ValueError('The earliest year must not be after the latest year.')
        if genre and genre not in self.genres:
            raise ValueError('Choose a genre from the list.')
        indices = [self.index[x] for x in seeds]
        profile = np.asarray(self.features[indices].mean(axis=0))
        if not np.any(profile):
            raise ValueError('These favorites have no genre data. Try another movie.')
        profile = normalize(profile)
        scores = np.asarray(self.features @ profile.T).ravel()
        blocked = set(seeds) | set(hidden)
        candidates = []
        for i, m in enumerate(self.movies):
            if m['id'] in blocked or scores[i] <= 1e-12:
                continue
            if genre and genre not in m['genres']:
                continue
            if avoid_horror and 'Horror' in m['genres']:
                continue
            if (min_year != 0 or max_year != 9999) and (m['year'] is None or not min_year <= m['year'] <= max_year):
                continue
            candidates.append(i)
        # Only score a profile against the catalog; never allocate N by N similarities.
        candidates.sort(key=lambda i: (-scores[i], self.movies[i]['title'], self.movies[i]['id']))
        pool = candidates[:200]
        selected = []
        while pool and len(selected) < limit:
            redundancy = np.zeros(len(pool))
            if selected and diversity:
                redundancy = (self.features[pool] @ self.features[selected].T).toarray().max(axis=1)
            utility = scores[pool] - diversity * redundancy
            position = int(np.argmax(utility))
            selected.append(pool.pop(position))
        profile_genres = {g for i in indices for g in self.movies[i]['genres']}
        results = []
        for i in selected:
            nearest = np.asarray((self.features[i] @ self.features[indices].T).toarray()).ravel()
            m = dict(self.movies[i])
            m['similarity'] = round(float(np.clip(scores[i], 0, 1)), 4)
            m['shared_genres'] = sorted(profile_genres.intersection(m['genres']))
            m['closest_favorite'] = self.movies[indices[int(np.argmax(nearest))]]['title']
            results.append(m)
        return {'results': results, 'eligible_count': len(candidates), 'diversity': diversity}
