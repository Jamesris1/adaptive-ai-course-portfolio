"""Local Flask GUI for the Movie Compass coursework project."""
from flask import Flask, jsonify, render_template, request
from recommender import MovieRecommender


def create_app(engine=None):
    app = Flask(__name__)
    app.config['MAX_CONTENT_LENGTH'] = 16384
    engine = engine or MovieRecommender()

    @app.get('/')
    def home():
        return render_template('index.html', count=len(engine.movies), genres=engine.genres)

    @app.get('/api/search')
    def search():
        query = request.args.get('q', '')
        return jsonify(engine.search(query[:100]))

    @app.post('/api/recommend')
    def recommend():
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify(error='Send a valid selection of movies.'), 400
        try:
            seeds, hidden = payload.get('seeds', []), payload.get('hidden', [])
            if not isinstance(seeds, list) or not isinstance(hidden, list):
                raise ValueError('Movie selections must be lists.')
            if len(hidden) > 1000 or any(type(x) is not int for x in hidden):
                raise ValueError('The hidden-movie list is invalid. Reset and try again.')
            genre = payload.get('genre', '')
            if not isinstance(genre, str):
                raise ValueError('Choose a genre from the list.')
            def integer(name, default):
                value = payload.get(name, default)
                if type(value) is not int:
                    raise ValueError('Years and result count must be whole numbers.')
                return value
            minimum, maximum = integer('min_year', 0), integer('max_year', 9999)
            if not 0 <= minimum <= 9999 or not 0 <= maximum <= 9999:
                raise ValueError('Enter years between 0 and 9999.')
            variety = payload.get('diversity', 0.15)
            if type(variety) not in (int, float) or variety not in (0, 0.15, 0.35):
                raise ValueError('Choose a variety option from the list.')
            avoid = payload.get('avoid_horror', False)
            if type(avoid) is not bool:
                raise ValueError('The horror filter must be true or false.')
            return jsonify(engine.recommend(seeds, hidden=hidden, genre=genre,
                           avoid_horror=avoid, min_year=minimum, max_year=maximum,
                           diversity=variety, limit=integer('limit', 8)))
        except (ValueError, TypeError):
            # TypeError can arise from malformed unhashable IDs; never expose a traceback.
            import sys
            error = sys.exception()
            message = str(error) if isinstance(error, ValueError) else 'Choose movies from the search results.'
            return jsonify(error=message), 400

    @app.after_request
    def privacy_headers(response):
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'"
        return response

    return app


if __name__ == '__main__':
    create_app().run(host='127.0.0.1', port=5055, debug=False)
