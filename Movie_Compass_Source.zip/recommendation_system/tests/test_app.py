import numpy as np
import pytest
from app import create_app
from recommender import MovieRecommender


@pytest.fixture(scope='module')
def engine():
    return MovieRecommender()


@pytest.fixture(scope='module')
def client(engine):
    return create_app(engine).test_client()


def test_catalog_and_search(engine):
    assert len(engine.movies) == 9742
    assert engine.search('toy story')[0]['id'] == 1
    assert engine.search('T') == []
    assert engine.search('no such movie zzzzzz') == []


def test_favorites_hidden_and_determinism(engine):
    first = engine.recommend([1, 260])
    ids = [m['id'] for m in first['results']]
    assert len(ids) == len(set(ids)) == 8
    assert not set(ids) & {1, 260}
    assert first == engine.recommend([1, 260])
    hidden = engine.recommend([1, 260], hidden=ids[:2])
    assert not set(ids[:2]) & {m['id'] for m in hidden['results']}


def test_exact_cosine_and_explanations(engine):
    answer = engine.recommend([1], diversity=0)
    seed = engine.features[engine.index[1]].toarray()[0]
    for movie in answer['results']:
        vector = engine.features[engine.index[movie['id']]].toarray()[0]
        expected = float(np.dot(seed, vector) / (np.linalg.norm(seed)*np.linalg.norm(vector)))
        assert movie['similarity'] == pytest.approx(expected, abs=0.0001)
        assert set(movie['shared_genres']) == set(movie['genres']) & set(engine.movies[engine.index[1]]['genres'])
    scores = [m['similarity'] for m in answer['results']]
    assert scores == sorted(scores, reverse=True)


def test_genre_year_horror_filters(engine):
    result = engine.recommend([1, 260], genre='Adventure', min_year=1990, max_year=2010, avoid_horror=True)
    assert result['results']
    for movie in result['results']:
        assert 1990 <= movie['year'] <= 2010
        assert 'Adventure' in movie['genres'] and 'Horror' not in movie['genres']


def test_empty_filter_is_honest(engine):
    assert engine.recommend([1], min_year=9999)['results'] == []
    assert engine.recommend([1], genre='Horror', avoid_horror=True)['eligible_count'] == 0


def test_empty_genres_need_recovery(engine):
    movie = next(m for m in engine.movies if not m['genres'])
    with pytest.raises(ValueError, match='no genre data'):
        engine.recommend([movie['id']])


@pytest.mark.parametrize('payload',[
    {}, {'seeds':[]}, {'seeds':[99999999]}, {'seeds':[[1]]}, {'seeds':[True]},
    {'seeds':'1'}, {'seeds':[1,2,3,4,5,6]}, {'seeds':[1],'hidden':[{}]},
    {'seeds':[1],'min_year':2000,'max_year':1990}, {'seeds':[1],'min_year':'hello'},
    {'seeds':[1],'genre':'not a genre'}, {'seeds':[1],'diversity':None},
    {'seeds':[1],'avoid_horror':'false'}, {'seeds':[1],'limit':0},
])
def test_invalid_requests_recover(client,payload):
    response=client.post('/api/recommend',json=payload)
    assert response.status_code == 400
    assert isinstance(response.json['error'],str)


def test_routes_and_privacy(client):
    response=client.get('/')
    assert response.status_code == 200
    assert b'Find your next' in response.data
    assert response.headers['Cache-Control']=='no-store'
    assert 'Set-Cookie' not in response.headers
    assert client.get('/api/search?q=Toy%20Story').json[0]['id']==1
    assert client.post('/api/recommend',json={'seeds':[1]}).status_code==200
    assert client.post('/api/recommend',data='invalid',content_type='application/json').status_code==400


def test_variety_control_changes_ranking(engine):
    closest=engine.recommend([1,260], diversity=0,limit=20)['results']
    varied=engine.recommend([1,260], diversity=.35,limit=20)['results']
    assert [m['id'] for m in closest] != [m['id'] for m in varied]
    assert all(0<=m['similarity']<=1 for m in varied)
