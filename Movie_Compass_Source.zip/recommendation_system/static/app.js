'use strict';
const $ = id => document.getElementById(id);
let favorites = [], hidden = [], searchVersion = 0, requestVersion = 0, timer;
function status(text, error=false) { $('status').textContent=text; $('status').className=error?'error':''; }
function element(tag, text, className='') { const node=document.createElement(tag); node.textContent=text; node.className=className; return node; }
function invalidate() { requestVersion++; $('recommend').disabled=false; $('results').replaceChildren(); status('Preferences changed. Choose Find recommendations to update.'); }
function renderFavorites() {
  $('favorites').replaceChildren();
  favorites.forEach(movie=>{const b=element('button',`${movie.title}  ×`);b.setAttribute('aria-label',`Remove ${movie.title}`);b.onclick=()=>{favorites=favorites.filter(m=>m.id!==movie.id);renderFavorites();invalidate();};$('favorites').append(b);});
  $('undo').disabled=!hidden.length;
}
$('search').addEventListener('input',()=>{
  clearTimeout(timer);const version=++searchVersion;const query=$('search').value.trim();$('search-results').replaceChildren();
  if(query.length<2)return;
  timer=setTimeout(async()=>{try{
    const response=await fetch(`/api/search?q=${encodeURIComponent(query)}`);if(!response.ok)throw new Error();const movies=await response.json();if(version!==searchVersion)return;
    if(!movies.length)$('search-results').append(element('p','No matching titles. Try fewer words.','small'));
    movies.forEach(movie=>{const b=element('button',movie.title);b.onclick=()=>{
      if(favorites.some(m=>m.id===movie.id)){status('That movie is already a favorite.');return;}
      if(favorites.length>=5){status('Remove a favorite before adding another. Five is the limit.',true);return;}
      favorites.push(movie);renderFavorites();invalidate();$('search').value='';$('search-results').replaceChildren();searchVersion++;$('search').focus();
    };$('search-results').append(b);});
  }catch{if(version===searchVersion)status('Search is unavailable. Check that the local app is running.',true);}},200);
});
async function recommend() {
  const version=++requestVersion;$('recommend').disabled=true;status('Finding movies that fit your preferences…');
  const year=id=>$(id).value===''?(id==='min-year'?0:9999):Number($(id).value);
  try {
    const response=await fetch('/api/recommend',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({seeds:favorites.map(m=>m.id),hidden,genre:$('genre').value,min_year:year('min-year'),max_year:year('max-year'),avoid_horror:$('avoid').checked,diversity:Number($('variety').value)})});
    const data=await response.json();if(version!==requestVersion)return;
    if(!response.ok)throw new Error(data.error||'Please check your selections.');
    $('results').replaceChildren();
    status(data.results.length?`${data.results.length} suggestions from ${data.eligible_count.toLocaleString()} eligible films. ${hidden.length} hidden.`:'No matches with these preferences. Broaden the years or genre, or undo a hidden movie.');
    data.results.forEach((movie,i)=>{
      const card=element('article','','card');card.append(element('div',`SUGGESTION ${String(i+1).padStart(2,'0')}`,'card-number'),element('h3',movie.title),element('div',movie.genres.join(' · '),'genres'));
      const reason=element('div','','reason');reason.append(element('strong','WHY THIS MOVIE'),element('span',`Matches your selected genres: ${movie.shared_genres.join(', ')}.`));
      card.append(reason,element('p',`Closest favorite: ${movie.closest_favorite}`,'small'),element('p',`Genre similarity: ${movie.similarity.toFixed(2)} / 1.00. Not a predicted rating.`,'small'));
      const hide=element('button','Hide this movie','text-button');hide.setAttribute('aria-label',`Hide ${movie.title}`);hide.onclick=()=>{hidden.push(movie.id);renderFavorites();recommend();};card.append(hide);$('results').append(card);
    });
  }catch(error){if(version===requestVersion){$('results').replaceChildren();status(error.message==='Failed to fetch'?'Connection lost. Start the local app and try again.':error.message,true);}}
  finally{if(version===requestVersion)$('recommend').disabled=false;}
}
$('recommend').onclick=recommend;
$('undo').onclick=()=>{hidden.pop();renderFavorites();recommend();};
$('demo').onclick=()=>{favorites=[{id:1,title:'Toy Story (1995)'}];hidden=[];renderFavorites();recommend();};
for(const id of ['genre','min-year','max-year','variety','avoid'])$(id).addEventListener('change',invalidate);
$('reset').onclick=()=>{favorites=[];hidden=[];searchVersion++;clearTimeout(timer);$('search').value='';$('search-results').replaceChildren();$('genre').value='';$('min-year').value='';$('max-year').value='';$('variety').value='0.15';$('avoid').checked=false;renderFavorites();invalidate();status('All choices cleared. Choose a favorite to begin.');$('search').focus();};
