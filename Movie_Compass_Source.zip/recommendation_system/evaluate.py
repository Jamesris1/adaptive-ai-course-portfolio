"""Reproducible development evaluation, not a user study or public benchmark."""
from pathlib import Path
import csv
import json
import math
import platform
import statistics
import time
from collections import Counter, defaultdict
import numpy as np
from recommender import MovieRecommender


def main():
    root=Path(__file__).resolve().parent
    engine=MovieRecommender()
    with (root/'data/ratings.csv').open(encoding='utf-8',newline='') as f:
        rows=[(int(r['userId']),int(r['movieId']),float(r['rating']),int(r['timestamp'])) for r in csv.DictReader(f)]
    cutoff=sorted(r[3] for r in rows)[int(.8*len(rows))]
    train=[r for r in rows if r[3]<cutoff]
    test=[r for r in rows if r[3]>=cutoff]
    catalog={r[1] for r in train}
    unavailable=set(engine.index)-catalog
    by_user=defaultdict(list)
    relevant=defaultdict(set)
    for r in train: by_user[r[0]].append(r)
    for user,movie,rating,_ in test:
        if rating>=4 and movie in catalog: relevant[user].add(movie)
    popularity=Counter(r[1] for r in train if r[2]>=4)
    popularity_order=sorted(catalog,key=lambda m:(-popularity[m],m))
    modes=('content_closest','content_balanced','content_variety','popularity','random')
    sums={mode:defaultdict(float) for mode in modes}
    coverage={mode:set() for mode in modes}
    latencies=[]; cohort=[]
    for user in sorted(by_user):
        history=sorted(by_user[user],key=lambda r:(r[3],r[1]))
        liked=[r[1] for r in history if r[2]>=4]
        seen={r[1] for r in history}
        targets=relevant[user]-seen
        if len(liked)<5 or not targets: continue
        seeds=liked[-5:]; cohort.append(user)
        blocked=seen|unavailable
        ranked={}
        for mode,weight in [('content_closest',0),('content_balanced',.15),('content_variety',.35)]:
            before=time.perf_counter()
            ranked[mode]=[m['id'] for m in engine.recommend(seeds,hidden=blocked,diversity=weight,limit=10)['results']]
            if mode=='content_balanced':latencies.append((time.perf_counter()-before)*1000)
        ranked['popularity']=[m for m in popularity_order if m not in seen][:10]
        candidates=sorted(catalog-seen)
        ranked['random']=np.random.default_rng(user).choice(candidates,size=min(10,len(candidates)),replace=False).tolist()
        for mode,ids in ranked.items():
            hits=sum(m in targets for m in ids)
            sums[mode]['hit_rate_at_10']+=float(hits>0)
            sums[mode]['precision_at_10']+=hits/10
            sums[mode]['recall_at_10']+=hits/len(targets)
            dcg=sum(1/math.log2(i+2) for i,m in enumerate(ids) if m in targets)
            ideal=sum(1/math.log2(i+2) for i in range(min(10,len(targets))))
            sums[mode]['ndcg_at_10']+=dcg/ideal
            if len(ids)>1:
                matrix=engine.features[[engine.index[m] for m in ids]]
                similarities=(matrix@matrix.T).toarray()
                sums[mode]['mean_pairwise_genre_similarity']+=float(similarities[np.triu_indices(len(ids),1)].mean())
            coverage[mode].update(ids)
    n=len(cohort)
    metrics={mode:{**{k:round(v/n,6) for k,v in sums[mode].items()},'catalog_coverage':round(len(coverage[mode])/len(catalog),6)} for mode in modes}
    output={'date':'2026-10-04','python':platform.python_version(),'catalog_movies':len(engine.movies),'ratings':len(rows),
            'cutoff_timestamp':cutoff,'train_ratings':len(train),'test_ratings':len(test),'candidate_catalog':len(catalog),'eligible_users':n,
            'method':'Global 80% timestamp cutoff; train strictly before cutoff; minimum five prior ratings >=4; last five positive titles as seeds. Test relevance is rating >=4 after cutoff for previously available, unseen items. Full eligible catalog, no negative sampling. No parameter tuning on test results.',
            'limitations':'Development snapshot, genre-only representation, selected users active across cutoff, no confidence intervals or human preference/usability study. Genre vocabulary fit on full static metadata; candidate movies restricted to training-observed IDs. Timing covers engine calls only on this computer.',
            'balanced_median_ms':round(statistics.median(latencies),3),'metrics':metrics,
            'toy_story_example':engine.recommend([1])}
    (root/'evidence').mkdir(exist_ok=True)
    (root/'evidence/evaluation.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in output.items() if k!='toy_story_example'},indent=2))


if __name__=='__main__':main()
