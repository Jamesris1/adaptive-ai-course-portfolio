# Movie Compass

A local, explainable movie recommendation system for MSAI-631. Select one to five favorite films, filter by genre/year, choose a variety level, and hide or restore recommendations. The AI technique is content-based recommendation using learned TF-IDF genre weights and cosine similarity. No API key or user account is required.

## Run on Windows

Use Python 3.12. From this folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

Open http://127.0.0.1:5055. Keep the terminal running; Ctrl+C stops the app. Installation needs internet; the app works offline afterward. The Flask development server is for local coursework, not internet deployment. For macOS/Linux, replace `.venv\Scripts\python.exe` with `.venv/bin/python` and use `python3.12` to create the environment.

## Try it

1. Click **Try a Toy Story example**, or search for a title and select a result.
2. Add up to five favorites. Choose **Find recommendations** after changing preferences.
3. Each card shows matching genres, its closest favorite, and cosine similarity. A score of 1.00 means identical direction in genre space, not perfect predicted enjoyment.
4. Try excluding Horror or limiting years. Contradictory filters honestly return no matches.
5. **Hide this movie** excludes it for this page session. **Undo hide** reverses the most recent hide. **Reset all** clears selections and filters. Reload also clears all state.

## What changed from the assigned example

Foundation: [shyam1998/Movie-Recommendation-System-GUI](https://github.com/shyam1998/Movie-Recommendation-System-GUI), commit `ef2a6020da3ba9f9af1f2da2341edc386d1adb86`. The original module and MIT license are preserved under `upstream/` for comparison; that module is not executed.

| Original design | This extension |
| --- | --- |
| Tkinter desktop interface and one title | Responsive Flask web interface and up to five favorites |
| IMDb sample, genre counts, ratings, normalized vote counts | MovieLens genre metadata with TF-IDF; ratings reserved for offline evaluation |
| Whole-catalog pairwise similarity matrix | Profile-to-catalog sparse scoring |
| First matching title and broad exception handling | Stable movie IDs, duplicate suppression, specific validation and recovery |
| Ranked titles with IMDb URLs | Explanations, year/genre constraints, hide/undo/reset, controllable diversity |

This is a rewritten extension of the example's recommendation pipeline, not a claim that the original project includes these changes. Albini's Flask tutorial informed the separation of web routes and presentation. No Netflix data or MongoDB is required.

## Algorithm

`TfidfVectorizer` treats each pipe-separated genre as a token. IDF is `log((1+N)/(1+df))+1`, followed by L2 normalization. Up to five favorite vectors are averaged and normalized. Their cosine similarity to catalog vectors establishes relevance. Favorites, hidden films, zero-overlap items, and filter failures are excluded. Equal scores use title then ID as deterministic tie breakers.

Variety reranks the top 200 eligible matches greedily: `utility = profile_similarity - diversity_weight * maximum_similarity_to_already_selected`. Weights are 0, 0.15, and 0.35. This reduces repeated genre profiles in some lists; it cannot guarantee novelty, quality, demographic fairness, or diversity of viewpoints. Identical genre vectors are still indistinguishable. The GUI displays eight results; evaluation uses ten.

## Reproduce checks

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe evaluate.py
```

The checked run passed 22 tests. `evidence/evaluation.json` records the actual development evaluation: 80,668 ratings before one global timestamp cutoff, 20,168 afterward, 7,867 training-observed candidate movies, and 28 eligible users with five prior positive ratings and at least one unseen positive test movie. Positives are ratings of at least four stars. The five most recent positive training titles seed the profile; all previously rated titles are excluded. Recommendations are evaluated against all positive test items, without negative sampling or test-set tuning.

Balanced content ranking achieved hit rate@10 0.178571 and NDCG@10 0.020220; the popularity baseline achieved 0.321429 and 0.096991. This modest genre-only model did not outperform popularity. Increasing variety reduced mean within-list cosine similarity from 0.909960 to 0.801462 relative to closest-only ranking. This is a narrow genre measure, not a user satisfaction result. Median balanced engine-call time was 10.884 ms on the development machine and will vary.

The 2018 MovieLens snapshot is a development dataset, not a shared research benchmark. This small selected cohort, fixed metadata, and absent user study limit conclusions. No live users were recruited or surveyed. See `evidence/verification.md` for browser checks.

## Data and responsible use

`data/movies.csv` contains 9,742 films. `ratings.csv` has 100,836 historical ratings from 610 anonymous user IDs and is used only by evaluation, not by the GUI. The app stores neither searches nor personal profiles. A local web server can log requested URLs during execution. No external analytics, accounts, cloud inference, or paid placements are used.

MovieLens data may be redistributed only under its original conditions, retained in `data/README.txt`. It is for research use; commercial use requires permission. Source/archive hashes are in `data/provenance.json`. Genres are not age ratings; filtering Horror does not make a title suitable for children. Data may be incomplete or outdated. These controls do not constitute a fairness audit.

## Files and submission

- `app.py`: routes, request validation, local server.
- `recommender.py`: content model and reranking.
- `templates/`, `static/`: web interface.
- `tests/`: functional and error-recovery checks.
- `evaluate.py`, `evidence/`: reproducible evaluation and verification.
- `data/`: attributed dataset and original terms.
- `upstream/`, `ATTRIBUTION.md`: baseline and resource credits.

Repository: https://github.com/Jamesris1/adaptive-ai-course-portfolio

The standalone submission archive is `Movie_Compass_Source.zip`; extract it and open the `recommendation_system` folder. The repository copy of that archive preserves this complete directory structure. The accompanying Word report describes the actual implementation and results. Review the code and personal reflection before submission.
